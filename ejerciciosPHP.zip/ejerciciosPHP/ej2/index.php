<?php
require_once 'config.php';
include 'header.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title><?= $site_title ?></title>
    <style>
       .inicial{
         background-color: lightcoral;
         text-align: center;
       }
       .letra{
           text-align: center;
       }
    </style>

</head>
<body>
<main class="inicial">
    <h1>Bienvenido a mi pagina de canciones</h1>
    <h2>Softcare</h2>
    <p class="letra">You've been my muse for a long time
        <br>
        You get me through every dark night
        <br>
        I'm always gone, out on the go
        <br>
        I'm on the run and you're home alone
        <br>
        I'm too consumed with my own life
        <br>
        Are we too young for this?
        <br>
        Feels like I can't move
        <br>
        Sharing my heart, it's tearing me apart
        <br>
        But I know I'd miss you, baby, if I left right now
        <br>
        Doing what I can, tryna be a man
        <br>
        And every time I kiss you, baby, I can hear the sound
        <br>
        Of breaking down
        <br>
        I've been confused as of late (yeah)
        <br>
        Watching my youth slip away (yeah)
        <br>
        You're like the sun, you wake me up
        <br>
        But you drain me out if I get too much
        <br>
        I might need room or I'll break
        <br>
        Are we too young for this?
        <br>
        Feels like I can't move</p>
    <img src="./imagenes/theN.jpg"
</main>
</body>
</html>
<?php
include 'footer.php'; ?>


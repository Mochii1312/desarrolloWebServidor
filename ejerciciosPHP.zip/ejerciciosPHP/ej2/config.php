<?php
$site_title = "Ej2";
$autor = "Elena Xian";
$fecha = date("d-m-Y");
$hora = date ("H:i:s");
?>